insert into TASK(task_id,task_name) values(1,'Compile')
insert into TASK(task_id,task_name) values(2,'Coding')
insert into TASK(task_id,task_name) values(3,'Testing')
insert into TASK(task_id,task_name) values(4,'Deploying')
