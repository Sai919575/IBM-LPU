package com.example.service;

import com.example.model.Task;

public interface TaskService {
	
	public Iterable<Task> getALlTasks();

}
