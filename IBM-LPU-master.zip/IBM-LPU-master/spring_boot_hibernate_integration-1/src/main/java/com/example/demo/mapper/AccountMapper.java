package com.example.demo.mapper;

import javax.persistence.MappedSuperclass;

@MappedS
public class AccountMapper {

}
