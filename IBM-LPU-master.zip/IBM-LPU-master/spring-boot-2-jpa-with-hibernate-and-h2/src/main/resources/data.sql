insert into student
values(10001,'John', 'E1234567');
insert into student
values(10003,'John', 'E1234567');
insert into student
values(10002,'Shane', 'A1234568');
